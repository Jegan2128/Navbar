# Vite React Tailwind Navbar - Ready for StackBlitz

How to use:
1. Upload this zip to StackBlitz (Create Project -> Upload Project) OR import from GitHub.
2. StackBlitz will install dependencies and start the dev server automatically.
3. The app uses BrowserRouter so the Navbar will render without useLocation errors.

