import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';

function Page({ title }) {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold">{title}</h1>
      <p className="mt-4 text-gray-700">This is the {title} page.</p>
      <div style={{ height: 800 }} />
    </div>
  );
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Page title="Home" />} />
        <Route path="/about" element={<Page title="About Us" />} />
        <Route path="/blog" element={<Page title="Blog" />} />
        <Route path="/gallery" element={<Page title="Gallery" />} />
        <Route path="/contact" element={<Page title="Contact" />} />
        <Route path="/courses/web-development" element={<Page title="Web Development" />} />
        <Route path="/courses/graphic-design" element={<Page title="Graphic Design" />} />
        <Route path="/courses/digital-marketing" element={<Page title="Digital Marketing" />} />
        <Route path="*" element={<Page title="Not Found" />} />
      </Routes>
    </>
  );
}
